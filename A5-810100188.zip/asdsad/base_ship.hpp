#ifndef Base_ship_H
#define Base_ship_H
#include<iostream>
#include <string>
#include <array>
#include <fstream>
#include <vector>
#include "rsdl.hpp"
#include "bullet.hpp"
using namespace std;


class base_ship
{
public:
	base_ship(Window*_window,int _loc_x,int _loc_y,int _status_dead_alive);
	void draw();
	void set_dir(char key);
	void clear_dir(char key);
	void move();
	void creat_bullet();
	void draw_bullets();
	void clear_bullet();
	void move_bullet();
	Rectangle get_rect();
	vector<BULLET *> get_them_to_enemy();
	
private:
	int loc_x;
	int loc_y;
	Rectangle shape;
	int status_dead_alive=1;
	int v_x=0;
	int v_y=0;
	Window * win;
	vector<BULLET *>bullets;

};
#endif