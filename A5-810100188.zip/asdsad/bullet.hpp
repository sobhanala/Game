#ifndef BULLET_H
#define BULLET_H
#include <iostream>
#include <string>
#include <array>
#include <fstream>
#include <vector>
#include "rsdl.hpp"
using namespace std;

class BULLET
{
public:
	BULLET(Window *_window, int _loc_x, int _loc_y);
	void draw();
	void move();
	void set_dir_bullet(char key);
	int get_y();
	int get_x();
	Rectangle get_shape_bullet();

private:
	int loc_x;
	int loc_y;
	Rectangle shape;
	int status_shown_not = 1;
	int v_y = 0;
	Window *win;
};
#endif