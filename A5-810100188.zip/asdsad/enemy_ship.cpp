#include "enemy_ship.hpp"
int const VELOCITY=2;
int const SQUARE_SIZE=100;

void enemy_ship::set_dir(){
    if(move_not==1){
    int dir=rand()%2;
    if(dir==1){
        v_x=VELOCITY;
    }
    else{
        v_x=-VELOCITY;
    }
    }
    if(move_not==0){
        v_x=0;
   }
}

enemy_ship::enemy_ship(Window*_window,int _loc_x,int _loc_y,int _move_not):shape_e( _loc_x,_loc_y,SQUARE_SIZE,SQUARE_SIZE){
		win=_window;
		loc_x=_loc_x;
		loc_y=_loc_y;
        move_not=_move_not;
        set_dir();
	}

void enemy_ship:: draw_enemy(){ 
        if((loc_x)>win->get_width()-SQUARE_SIZE){
            loc_x=win->get_width()-SQUARE_SIZE;
            change_dir();
        }
        if(loc_x<0){
            loc_x=0;
            change_dir();
        }
        shape_e=Rectangle(loc_x,loc_y,SQUARE_SIZE,SQUARE_SIZE);
        win->draw_img("s.png",shape_e,NULL_RECT,(0.0),true,true);
       
       
	
}

void enemy_ship::draw_bullets(){
    for (int i = 0 ; i < bullets.size() ; i++){
        bullets[i]->draw() ;
    }
}

void enemy_ship:: clear_bullet(){
    for (int bullet = 0; bullet < bullets.size(); bullet++)
    {
        if(bullets[bullet]->get_y()>win->get_height()){
        delete bullets[bullet];
        bullets.erase(bullets.begin()+bullet);
        bullet--;
        }
    }
}

void enemy_ship::creat_bullet(){
    BULLET * temp=new BULLET(win,loc_x,loc_y);
    temp->set_dir_bullet('d');
    bullets.push_back(temp);

}

void enemy_ship::shoot(){
    draw_bullets();  
}

void enemy_ship::move_bullets(){
     for (int i = 0 ; i < bullets.size() ; i++){
        bullets[i]->move() ;
    }
}

void enemy_ship::change_dir(){
    v_x=-(v_x);
}

void enemy_ship::move_enemy(){
    loc_x=loc_x+v_x;
	loc_y=loc_y+v_y;
}

int  enemy_ship::get_x(){
    return loc_x;

}

vector<BULLET *>  enemy_ship:: get_bullets(){
    return bullets;
}

Rectangle enemy_ship::get_rect(){
    return shape_e;
}

