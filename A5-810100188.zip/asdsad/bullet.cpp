#include "bullet.hpp"

using namespace std;

 BULLET::BULLET(Window*_window,int _loc_x,int _loc_y):shape( _loc_x,_loc_y,100,100){
		win=_window;
		loc_x=_loc_x;
		loc_y=_loc_y;
	}



void BULLET:: draw(){
    shape=Rectangle(loc_x,loc_y,10,10);
    if(status_shown_not==1){
        win->fill_rect(shape);
    }
}

int  BULLET:: get_y(){
   return loc_y;
}
void  BULLET::set_dir_bullet(char key){
    if(key=='d'){
        v_y=2;
    }
    if(key=='u'){
        v_y=-2;
    }	 
}

void BULLET::move(){
    loc_y=loc_y+v_y;
}
int BULLET::get_x(){
    return loc_x;
}
Rectangle BULLET::get_shape_bullet(){
    return shape ;
}

