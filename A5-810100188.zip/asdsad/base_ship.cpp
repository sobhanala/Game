#include "base_ship.hpp"
#include "bullet.hpp"
int const SQUARE_SIZE=100;
int const VELOCITY=5;
char const UP='u';
using namespace std;

 base_ship::base_ship(Window*_window,int _loc_x,int _loc_y,int _status_dead_alive) : shape( _loc_x,_loc_y,SQUARE_SIZE,SQUARE_SIZE) {
		win=_window;
		loc_x=_loc_x;
		loc_y=_loc_y;
	}

void base_ship:: draw(){
	if(status_dead_alive!=0){ 
        if((loc_x)>win->get_width()-SQUARE_SIZE){
            loc_x=win->get_width()-SQUARE_SIZE;
        }
        if((loc_y)>win->get_height()-SQUARE_SIZE){
            loc_y=win->get_height()-SQUARE_SIZE;
        }
        if(loc_x<0){
            loc_x=0;
        }
        if(loc_y<0){
            loc_y=0;
        }
       shape=Rectangle(loc_x,loc_y,SQUARE_SIZE,SQUARE_SIZE),
	   win->draw_img("spaceship.png",shape,NULL_RECT,(0.0),true);

	}
}

void base_ship::draw_bullets(){
    for (int i = 0 ; i < bullets.size() ; i++){
        bullets[i]->draw() ;
    }
}

void base_ship:: move_bullet(){
    for (int i = 0 ; i < bullets.size() ; i++){
        bullets[i]->move() ;
    }
}

void base_ship:: clear_bullet(){
    for (int i = 0; i < bullets.size(); i++)
    {
        if(bullets[i]->get_y()>win->get_height()){
        delete bullets[i];
        bullets.erase(bullets.begin()+i);
        i--;
        }
    }
}

void  base_ship::set_dir(char key){
	 switch(key) {
        case 'd':
            v_x = VELOCITY;
            break;
        case 'a':
            v_x = -VELOCITY;
            break;
        case 'w':
            v_y = -VELOCITY;
			break;
		case 's':
		v_y= 5;
            break;
        case ' ':
            creat_bullet();
            bullets[(bullets.size()-1)]->set_dir_bullet(UP);

	}
	}

void  base_ship::clear_dir(char key){	
	if(key=='d'|| key=='w'|| key=='s'||key=='a'){
		v_x=0;
		v_y=0;
	}
	}

void  base_ship::move(){
    loc_x=loc_x+v_x;
	loc_y=loc_y+v_y;
}

void base_ship::creat_bullet(){
    BULLET * temp=new BULLET(win,loc_x,loc_y);
    bullets.push_back(temp);

}

vector<BULLET *>  base_ship::get_them_to_enemy(){
    return bullets;
}

Rectangle  base_ship:: get_rect(){
    return shape;
}