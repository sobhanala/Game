#ifndef GAME_H
#define GAME_H
#include<iostream>
#include <string>
#include <array>
#include <fstream>
#include <vector>
#include "rsdl.hpp"
#include "base_ship.hpp"
#include "enemy_ship.hpp"
#include "hostage.hpp"
using namespace std;

class Game {
public:
Game(base_ship * ship_, Window* window_);	
void update(int &counter);
void handle_events(); 
void add_enemy( Window * window ,int satr,int soton,int i , int j,int side);
void add_enemy_hostage(Window * window ,int satr,int soton,int i , int j);
int draw();
void draw_delay();
void get_input(string input);
void check_winner();
bool hit_or_not (Rectangle a_rec , Rectangle b_rec);
void showe_lose(int result);
void erase_enemy();
void remove_from_game(int index);
void read_map(int index);
void draw_enemy();
void draw_ship();
void draw_hostage();
private:
 
  int is_winner=0;
  base_ship * ship;
  Window * window;
  vector <enemy_ship *> enemy;
  vector <hostage *> hostage_vec;
  BULLET * bullet;
  int  round_pass=0;
  int enemy_num=enemy.size();
};
#endif