#include "hostage.hpp"
int const SQUARE_SIZE=150;
hostage::hostage(Window*_window,int _loc_x,int _loc_y):hostage_rec( _loc_x,_loc_y,SQUARE_SIZE,SQUARE_SIZE){
    win=_window;
    loc_x=_loc_x;
    loc_y=_loc_y;
}
void hostage::draw_hostage(){
    hostage_rec=Rectangle(loc_x,loc_y,SQUARE_SIZE,SQUARE_SIZE);
    win->draw_img("e.png",hostage_rec,NULL_RECT,(0.0),true,true);
}
Rectangle hostage::get_rect(){
    return hostage_rec;
}
