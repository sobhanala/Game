#include<iostream>
#include <string>
#include <array>
#include <fstream>
#include <vector>
#include "rsdl.hpp"
#include "base_ship.hpp"
#include "enemy_ship.hpp"
#include "Game.hpp"
using namespace std;

int main(int argc, char  *argv[])
{
	Window * window=new Window(1000,1000,"plane");
	base_ship * a=new base_ship(window,1000,1000,1);
	Game y=Game(a,window);
	int result=0;
	int counter=0;

	
		y.read_map(0);
		while(result==0){
		y.handle_events();
		y.update(counter);
		result=y.draw();
		delay(10);
		}
	    y.showe_lose(result);
	

	return 0;
}