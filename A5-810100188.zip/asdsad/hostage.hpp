#ifndef HOSTAGE_H
#define HOSTAGE_H
#include<iostream>
#include <string>
#include <array>
#include <fstream>
#include <vector>
#include "rsdl.hpp"
#include "base_ship.hpp"
#include "enemy_ship.hpp"

class hostage
{
private:
int loc_x;
int loc_y;
Rectangle hostage_rec;
Window * win;

public:
    hostage(Window*_window,int _loc_x,int _loc_y);
    void draw_hostage();   
    Rectangle get_rect();
  
};





























#endif