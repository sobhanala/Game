#ifndef ENEMY_SHIP_H
#define ENEMY_SHIP_H
#include<iostream>
#include <string>
#include <array>
#include <fstream>
#include <vector>
#include "rsdl.hpp"
#include "bullet.hpp"
#include <unistd.h>

using namespace std;

class enemy_ship
{
public:
    enemy_ship(Window*_window,int _loc_x,int _loc_y,int _move_not);
	void move_enemy();
    void set_dir();
    void change_dir();
    void draw_enemy();   
	void creat_bullet();
	void draw_bullets();
	void clear_bullet();
	void shoot();
	void move_bullets();
	int  get_x();
	Rectangle get_rect();
	vector<BULLET *>get_bullets();
	int move_not;
private:
	
	int loc_x;
	int loc_y;
	Rectangle shape_e;
	int v_x=0;
	int v_y=0;
	Window * win;
	vector<BULLET *>bullets;
};
#endif