#include "Game.hpp"
string const LOSE="YOU LOSE !!!!";
string const WIN="YOU WON !!!!";
int ALLI_WON=2;
int ENEMEY_WON=1;
const string input_file="input.txt";
const string space=" ";
const char MOVING_ENEMY='E';
const char NOT_MOVING_ENEMY='M';
const char HOSTAGE_ENEMY='S';
const int MOVER=1;
const int NOT_MOVER=0;
const int HOSTAGE=2;

Game::Game(base_ship * ship_, Window* window_){
  		window=window_;
  		ship=ship_;
  	}

void Game::handle_events() {
    while(window->has_pending_event()) {
	
		ship->move();
    	Event e = window->poll_for_event();
    	switch (e.get_type()) {
        case Event::EventType::QUIT:
          exit(0);
          break;
        case Event::EventType::KEY_PRESS:
            ship->set_dir(e.get_pressed_key());
			break;
        case Event::KEY_RELEASE:
            ship->clear_dir(e.get_pressed_key());
            break;
            
          default:
		  	break;
      }
    }
  }

void Game::update(int & counter){
	for(int i=0;i<enemy.size();i++){
    enemy[i]->move_enemy();
    if(enemy[i]->get_x()==(i+1)*100 or enemy[i]->get_x()==(i+1)*200 or enemy[i]->get_x()==(i+1)*300 and enemy[i]->move_not==MOVER){
        enemy[i]->creat_bullet();  
        }
    if((enemy[i]->move_not)==0 and (counter%150==0)){
        enemy[i]->creat_bullet();  
    }
	enemy[i]->move_bullets(); 
    check_winner();
    enemy[i]->clear_bullet(); 
	}
	
    ship->move_bullet();
    check_winner();
    ship->clear_bullet();
     check_winner();
     counter++;
    
}

void  Game::read_map(int index)
{
    string temp;
    ifstream my_file(input_file);
    int m_satr,n_sotoon;
    int rounds;
    vector<string> temp_table;
 
  
    getline(my_file,temp);
    m_satr=temp[0]-48;
    n_sotoon=temp[2]-48;
    getline(my_file,temp);
    rounds=temp[0]-48;
          

for (int  z = 0; z <index*m_satr; z++)
{
    getline(my_file,temp);
}
for (int  i = 0; i <m_satr; i++)
{
    getline(my_file,temp);
    for(int j=0;j<n_sotoon;j++){
        if(temp[j]==MOVING_ENEMY){
            add_enemy(window,m_satr,n_sotoon,j,i,MOVER);
        }
        if(temp[j]==NOT_MOVING_ENEMY){
            add_enemy(window,m_satr,n_sotoon,j,i,NOT_MOVER);
        }
        if(temp[j]==HOSTAGE_ENEMY){
            
            add_enemy_hostage(window,m_satr,n_sotoon,j,i);
        }
    }
}

}

void Game::draw_enemy(){
  for(auto enem:enemy){
		enem->draw_enemy();
	}      
}

void Game::draw_ship(){
    ship->draw();
	ship->draw_bullets();
}

void Game::draw_hostage(){
    for (auto hostage:hostage_vec)
    {
        hostage->draw_hostage();
    }
    
}

int  Game:: draw(){
    window->clear();
    if(is_winner==ENEMEY_WON){
        return ENEMEY_WON;
    }
    if(is_winner==ALLI_WON){
        return ALLI_WON;
    }
	window->draw_img("image.jpg",Rectangle(0,0,window->get_width(),window->get_height()));
    draw_enemy();
    draw_ship();
    draw_hostage();
    for (int  i = 0; i < enemy.size(); i++)
    {
        enemy[i]->shoot();
    }
	window->update_screen();
    return 0;
  }

void Game:: add_enemy( Window * window ,int satr,int soton,int i , int j,int side){
	enemy_ship * a=new enemy_ship(window,((window->get_width())/satr)*i,((window->get_height()/soton)*j),side);
	enemy.push_back(a);

}

void Game::check_winner(){
    for(int  i = 0; i < enemy.size(); i++){
        enemy_num=enemy.size();
        for(auto bullet:enemy[i]->get_bullets()){
            if(hit_or_not(ship->get_rect(),bullet->get_shape_bullet())==true){
                is_winner=ENEMEY_WON;
                break;     
            }
        }  
        for(auto bullet:ship->get_them_to_enemy()){
                auto b=enemy[i]->get_rect();
                auto c=bullet->get_shape_bullet();
                if(hit_or_not(b,c)==true){
                    enemy.erase(enemy.begin()+i);
                    enemy_num--;
                    if (enemy_num<=0)
                    {
                        is_winner=ALLI_WON;
                        break;
                    }
           
            }         
        }
        if (hit_or_not(ship->get_rect(),enemy[i]->get_rect())==true)
        {   
            is_winner=ENEMEY_WON;
            break;
        }
           
}
    for (int j = 0; j < hostage_vec.size(); j++)
    {
        for(auto bullets:ship->get_them_to_enemy()){
            if(hit_or_not(hostage_vec[j]->get_rect(),bullets->get_shape_bullet())){
                is_winner=ENEMEY_WON;
                break;   
            }
        }
        if (hit_or_not(ship->get_rect(),hostage_vec[j]->get_rect())==true)
        {   
            is_winner=ENEMEY_WON;
            break;
            
        }
    }
    


}

bool Game::hit_or_not (Rectangle a , Rectangle b){
    if(((a.x>b.x) and (a.x<b.x+b.w)) or ((a.x+a.h>b.x) and (a.x+a.h<b.x+a.w))){
        if(((a.y>b.y) and (a.y<b.y+b.h)) or  ((a.y+a.h>b.y) and (a.y+a.h<b.y+a.h))){
            return true;
        }
        return false;
    }
    return false;
}

void Game::showe_lose(int result){
    int time_conter=0;
    
    while (time_conter<1000)
    {
        time_conter++;
        window->clear();
        if(result==ENEMEY_WON)
            window->show_text(LOSE,Point(200,500),WHITE,"font.ttf",50);
        if(result==ALLI_WON)
            window->show_text(WIN,Point(200,500),WHITE,"font.ttf",50);
 
        window->update_screen();
    }
    
}

void Game::add_enemy_hostage( Window * window ,int satr,int soton,int i , int j){
    hostage * a=new hostage(window,((window->get_width())/satr)*i,((window->get_height()/soton)*j));
	hostage_vec.push_back(a);

}